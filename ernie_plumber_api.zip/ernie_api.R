
# Load necessary libraries
library(plumber)
library(httr)
library(jsonlite)

#* @post /chat
#* @param message The user's chat message
function(req, res, message="") {
  openai_key <- Sys.getenv("OPENAI_API_KEY")
  if (openai_key == "") {
    res$status <- 500
    return(list(error = "API key missing!"))
  }
  if (nchar(message) < 1) {
    res$status <- 400
    return(list(error = "Empty message."))
  }
  response <- httr::POST(
    url = "https://api.openai.com/v1/chat/completions",
    add_headers(
      Authorization = paste("Bearer", openai_key),
      "Content-Type" = "application/json"
    ),
    body = toJSON(list(
      model = "gpt-3.5-turbo",
      messages = list(
        list(role = "system", content = "You are Ernie, a helpful assistant for earnings tax questions."),
        list(role = "user", content = message)
      )
    ), auto_unbox = TRUE)
  )
  if (response$status_code != 200) {
    res$status <- response$status_code
    return(list(error = content(response)$error$message))
  }
  out <- content(response, as = "parsed", type = "application/json")
  list(reply = out$choices[[1]]$message$content)
}
